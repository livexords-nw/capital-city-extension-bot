// ==UserScript==
// @name         Capital City Helper
// @namespace    http://tampermonkey.net/
// @version      1.3.11
// @description  Main menu dengan Update Info, Status, Game (Rat Hunter, Treasure Hunter & Grass Farm), Regen Kesehatan, dan Regen Energy untuk Capital City. Status tetap menggunakan /ajax.php, sedangkan Grass Farm diambil dari /grass.php dan fitur buy seeds, buy water, dan water grass tersedia.
// @match        https://capitalcity.web.id/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // ----- SIMPAN PLAYER_ID JIKA URL MENGANDUNG travelling.php?player_id=... -----
    if (window.location.href.indexOf("travelling.php") !== -1 && window.location.href.indexOf("player_id=") !== -1) {
        let params = new URLSearchParams(window.location.search);
        let pid = params.get("player_id");
        if (pid) {
            localStorage.setItem("capitalCityPlayerId", pid);
            console.log("Player ID disimpan: " + pid);
        }
    }

    /* === CSS: Main Menu, Popup, Game Menu & Lainnya === */
    GM_addStyle(`
        /* Main Menu Styles */
        #mainMenu {
            position: fixed;
            top: 10px;
            left: 10px;
            background: #2e2e2e;
            border: 1px solid #444;
            z-index: 9999;
            width: 220px;
            padding-bottom: 5px;
        }
        #mainMenuHeader {
            background: #3a3a3a;
            padding: 5px;
            text-align: center;
            border-bottom: 1px solid #444;
            color: #fff;
            cursor: move;
        }
        #mainMenuContent {
            padding: 5px;
        }
        #mainMenu button {
            margin: 2px 0;
            padding: 5px 10px;
            background: #3a3a3a;
            border: 1px solid #444;
            color: #eee;
            cursor: pointer;
            width: 100%;
        }
        /* Footer di main menu */
        #mainMenuFooter {
            font-size: 10px;
            text-align: center;
            margin-top: 5px;
            color: #aaa;
        }
        /* Tombol pada Popup, disamakan dengan main menu */
        .popup button {
            margin: 2px 0;
            padding: 5px 10px;
            background: #3a3a3a;
            border: 1px solid #444;
            color: #eee;
            cursor: pointer;
        }
        /* Popup Styles Umum */
        .popup {
            position: fixed;
            background: #2e2e2e;
            border: 1px solid #444;
            color: #eee;
            z-index: 10000;
            box-shadow: 1px 1px 3px rgba(0,0,0,0.5);
            overflow: auto;
            max-height: 80vh;
        }
        .popupHeader {
            background: #3a3a3a;
            padding: 5px;
            cursor: move;
            user-select: none;
            border-bottom: 1px solid #444;
            position: relative;
        }
        .popupHeader .closeBtn,
        .popupHeader .minimizeBtn {
            position: absolute;
            top: 5px;
            font-weight: bold;
            cursor: pointer;
        }
        .popupHeader .closeBtn { right: 10px; }
        .popupHeader .minimizeBtn { right: 30px; }
        .popupContent { padding: 10px; }
        /* Popup khusus untuk Regen Kesehatan */
        .regenKesehatanPopup {
            top: 50px;
            left: 500px;
            width: 350px;
        }
        /* Popup untuk Regen Energy */
        .regenEnergyPopup {
            top: 50px;
            left: 500px;
            width: 350px;
        }
        /* Status Popup */
        .statusPopup {
            top: 50px;
            left: 400px;
            width: 400px;
        }
        /* Game Menu Popup */
        .gameMenuPopup {
            top: 50px;
            left: 750px;
            width: 320px;
        }
        /* Treasure Hunter Popup */
        .treasureHunterPopup {
            top: 50px;
            left: 750px;
            width: 400px;
        }
        /* Rat Hunter Popup */
        .ratHunterPopup {
            top: 50px;
            left: 750px;
            width: 400px;
        }
        /* Grass Farm Popup */
        .grassFarmPopup {
            top: 50px;
            left: 750px;
            width: 500px;
        }
    `);

    /* === Utility: Draggable & Toggle Minimize === */
    function makeDraggable(el, handle) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        handle.onmousedown = dragMouseDown;
        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }
        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            el.style.top = (el.offsetTop - pos2) + "px";
            el.style.left = (el.offsetLeft - pos1) + "px";
        }
        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }
    function toggleMinimize(popup, contentSelector, btn) {
        let content = popup.querySelector(contentSelector);
        if (content.style.display === "none") {
            content.style.display = "block";
            btn.textContent = "–";
        } else {
            content.style.display = "none";
            btn.textContent = "+";
        }
    }

    /* === MAIN MENU === */
    let mainMenu = document.createElement("div");
    mainMenu.id = "mainMenu";
    mainMenu.innerHTML = `
        <div id="mainMenuHeader">Capital City Helper</div>
        <div id="mainMenuContent">
            <button id="openUpdate">Update Info</button>
            <button id="openStatus">Status</button>
            <button id="openGame">Game</button>
            <button id="regenKesehatan">Regen Kesehatan</button>
            <button id="regenEnergy">Regen Energy</button>
        </div>
        <div id="mainMenuFooter">Creator: LIVEXORDS | v1.3.11</div>
    `;
    document.body.appendChild(mainMenu);
    makeDraggable(mainMenu, mainMenu.querySelector("#mainMenuHeader"));

    /* === STATUS POPUP (tetap seperti sebelumnya) === */
    let statusPopup = null;
    function loadStatusData() {
        fetch("https://capitalcity.web.id/ajax.php", {
            method: "GET",
            headers: {
                "Accept": "text/html, */*; q=0.01",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "X-Requested-With": "XMLHttpRequest"
            },
            credentials: "same-origin"
        })
        .then(response => response.text())
        .then(text => {
            let parser = new DOMParser();
            let doc = parser.parseFromString(text, "text/html");
            let stats = doc.querySelector("#stats");
            let stats2 = doc.querySelector("#stats2");
            let skills = doc.querySelector("#skills");
            let online = doc.querySelector("#online");
            let combinedHTML = "";
            if (stats) combinedHTML += stats.outerHTML;
            if (stats2) combinedHTML += stats2.outerHTML;
            if (skills) combinedHTML += skills.outerHTML;
            if (online) combinedHTML += online.outerHTML;
            document.getElementById("statusContainer").innerHTML = combinedHTML;
        })
        .catch(err => {
            document.getElementById("statusContainer").innerHTML = "Error loading status data.";
            console.error(err);
        });
    }
    function createStatusPopup() {
        if (statusPopup) { statusPopup.remove(); }
        statusPopup = document.createElement("div");
        statusPopup.className = "popup statusPopup";
        statusPopup.style.top = "50px";
        statusPopup.style.left = "400px";
        statusPopup.style.width = "400px";
        statusPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Status</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="refreshBtn" title="Refresh">⟳</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <div id="statusContainer">Loading...</div>
            </div>
        `;
        document.body.appendChild(statusPopup);
        makeDraggable(statusPopup, statusPopup.querySelector(".popupHeader"));
        statusPopup.querySelector(".closeBtn").addEventListener("click", () => {
            statusPopup.remove();
            statusPopup = null;
        });
        statusPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(statusPopup, ".popupContent", this);
        });
        statusPopup.querySelector(".refreshBtn").addEventListener("click", loadStatusData);
        loadStatusData();
    }
    document.getElementById("openStatus").addEventListener("click", createStatusPopup);

    /* === REGEN KESEHATAN POPUP (tetap seperti sebelumnya) === */
    let regenKesehatanPopup = null;
    function createRegenKesehatanPopup() {
        if (regenKesehatanPopup) { regenKesehatanPopup.remove(); }
        regenKesehatanPopup = document.createElement("div");
        regenKesehatanPopup.className = "popup regenKesehatanPopup";
        regenKesehatanPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Regen Kesehatan</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <div id="regenKesehatanStatus">Loading current kesehatan...</div>
                <br>
                <button id="refreshRegenStatus">Refresh Status</button>
                <button id="doRegenKesehatan">Regen Now</button>
            </div>
        `;
        document.body.appendChild(regenKesehatanPopup);
        makeDraggable(regenKesehatanPopup, regenKesehatanPopup.querySelector(".popupHeader"));
        regenKesehatanPopup.querySelector(".closeBtn").addEventListener("click", () => {
            regenKesehatanPopup.remove();
            regenKesehatanPopup = null;
        });
        regenKesehatanPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(regenKesehatanPopup, ".popupContent", this);
        });
        // Mengambil data kesehatan dari ajax.php
        function loadRegenKesehatanStatus() {
            fetch("https://capitalcity.web.id/ajax.php", {
                method: "GET",
                headers: {
                    "Accept": "text/html, */*; q=0.01",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "X-Requested-With": "XMLHttpRequest"
                },
                credentials: "same-origin"
            })
            .then(response => response.text())
            .then(text => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(text, "text/html");
                // Ambil data kesehatan dari progress bar dengan kelas .progress-bar.bg-success
                let progressBar = doc.querySelector(".progress-bar.bg-success");
                if (progressBar) {
                    let textContent = progressBar.textContent.trim(); // misal "0 / 100"
                    let match = textContent.match(/(\d+)\s*\/\s*100/);
                    if (match) {
                        let currentKesehatan = parseInt(match[1]);
                        document.getElementById("regenKesehatanStatus").textContent = "Kesehatan: " + currentKesehatan + "/100";
                    } else {
                        document.getElementById("regenKesehatanStatus").textContent = "Data kesehatan tidak ditemukan.";
                    }
                } else {
                    document.getElementById("regenKesehatanStatus").textContent = "Elemen progress tidak ditemukan.";
                }
            })
            .catch(err => {
                document.getElementById("regenKesehatanStatus").textContent = "Error loading status: " + err;
            });
        }
        function doRegenKesehatan() {
            fetch("https://capitalcity.web.id/ajax.php", {
                method: "GET",
                headers: {
                    "Accept": "text/html, */*; q=0.01",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "X-Requested-With": "XMLHttpRequest"
                },
                credentials: "same-origin"
            })
            .then(response => response.text())
            .then(text => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(text, "text/html");
                let progressBar = doc.querySelector(".progress-bar.bg-success");
                if (progressBar) {
                    let textContent = progressBar.textContent.trim();
                    let match = textContent.match(/(\d+)\s*\/\s*100/);
                    if (match) {
                        let currentKesehatan = parseInt(match[1]);
                        let missingKesehatan = 100 - currentKesehatan;
                        if (missingKesehatan <= 0) {
                            alert("Kesehatan sudah penuh (" + currentKesehatan + "/100).");
                            return;
                        }
                        let playerId = localStorage.getItem("capitalCityPlayerId");
                        if (!playerId) {
                            alert("Player ID belum diset. Silakan set terlebih dahulu.");
                            return;
                        }
                        const payload = {
                            playerId: playerId,
                            moneyEarned: 0,
                            reduceHealth: -missingKesehatan
                        };
                        const headers = {
                            "Accept": "*/*",
                            "Cache-Control": "no-cache",
                            "Pragma": "no-cache",
                            "Content-Type": "application/json",
                            "Origin": "https://capitalcity.web.id",
                            "Referer": "https://capitalcity.web.id/arrow.php",
                            "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "\"Windows\""
                        };
                        fetch("https://capitalcity.web.id/update.php", {
                            method: "POST",
                            headers: headers,
                            credentials: "same-origin",
                            body: JSON.stringify(payload)
                        })
                        .then(response => response.text())
                        .then(text => {
                            loadRegenKesehatanStatus();
                        })
                        .catch(err => {
                            alert("Regen Kesehatan Error: " + err);
                            console.error(err);
                        });
                    } else {
                        alert("Tidak dapat menemukan data kesehatan.");
                    }
                } else {
                    alert("Elemen progress tidak ditemukan.");
                }
            })
            .catch(err => {
                alert("Error fetching status: " + err);
                console.error(err);
            });
        }
        document.getElementById("refreshRegenStatus").addEventListener("click", loadRegenKesehatanStatus);
        document.getElementById("doRegenKesehatan").addEventListener("click", doRegenKesehatan);
        loadRegenKesehatanStatus();
    }
    document.getElementById("regenKesehatan").addEventListener("click", createRegenKesehatanPopup);

    /* === REGEN ENERGY POPUP === */
    let regenEnergyPopup = null;
    function createRegenEnergyPopup() {
        if (regenEnergyPopup) { regenEnergyPopup.remove(); }
        regenEnergyPopup = document.createElement("div");
        regenEnergyPopup.className = "popup regenEnergyPopup";
        regenEnergyPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Regen Energy</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <div id="regenEnergyStatus">Loading current energy...</div>
                <br>
                <button id="refreshRegenEnergy">Refresh Energy</button>
                <button id="doRegenEnergy">Regen Now</button>
            </div>
        `;
        document.body.appendChild(regenEnergyPopup);
        makeDraggable(regenEnergyPopup, regenEnergyPopup.querySelector(".popupHeader"));
        regenEnergyPopup.querySelector(".closeBtn").addEventListener("click", () => {
            regenEnergyPopup.remove();
            regenEnergyPopup = null;
        });
        regenEnergyPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(regenEnergyPopup, ".popupContent", this);
        });

        // Header khusus untuk request ke shop.php
        const shopHeaders = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
            "Cache-Control": "no-cache",
            "Cookie": "PHPSESSID=52c074rqh5735qh67s0ho6s7qt",
            "Pragma": "no-cache",
            "Priority": "u=0, i",
            "Referer": "https://capitalcity.web.id/work.php",
            "Sec-CH-UA": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
            "Sec-CH-UA-Mobile": "?0",
            "Sec-CH-UA-Platform": "\"Windows\"",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
        };

        // Mengambil status energy dari ajax.php (meniru regen kesehatan)
        function loadRegenEnergyStatus() {
            fetch("https://capitalcity.web.id/ajax.php", {
                method: "GET",
                headers: {
                    "Accept": "text/html, */*; q=0.01",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "X-Requested-With": "XMLHttpRequest"
                },
                credentials: "same-origin"
            })
            .then(response => response.text())
            .then(text => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(text, "text/html");
                // Cari container yang memiliki class col-lg-6 dan mengandung teks "Energy"
                let energyContainer = Array.from(doc.querySelectorAll("div.col-lg-6"))
                    .find(el => el.textContent.includes("Energy"));
                let energyBar = energyContainer ? energyContainer.querySelector(".progress-bar") : null;
                if (energyBar) {
                    let textContent = energyBar.textContent.trim(); // misal "79 / 100"
                    let match = textContent.match(/(\d+)\s*\/\s*(\d+)/);
                    if (match) {
                        let currentEnergy = parseInt(match[1]);
                        let maxEnergy = parseInt(match[2]);
                        document.getElementById("regenEnergyStatus").textContent = "Energy: " + currentEnergy + "/" + maxEnergy;
                    } else {
                        document.getElementById("regenEnergyStatus").textContent = "Data energy tidak ditemukan.";
                    }
                } else {
                    document.getElementById("regenEnergyStatus").textContent = "Elemen progress energy tidak ditemukan.";
                }
            })
            .catch(err => {
                document.getElementById("regenEnergyStatus").textContent = "Error loading energy: " + err;
                console.error(err);
            });
        }

        // Fungsi untuk mengambil link regen energy dari shop.php
        function loadRegenEnergyLink(callback) {
            fetch("https://capitalcity.web.id/shop.php", {
                method: "GET",
                headers: shopHeaders,
                credentials: "same-origin"
            })
            .then(response => response.text())
            .then(html => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(html, "text/html");
                // Cari link yang mengandung "buy-id=56"
                let linkEl = doc.querySelector('a[href*="buy-id=56"]');
                if (linkEl) {
                    let regenLink = linkEl.getAttribute("href");
                    callback(null, regenLink);
                } else {
                    callback("Link regen energy tidak ditemukan.", null);
                }
            })
            .catch(err => {
                callback(err, null);
            });
        }

        // Fungsi untuk melakukan regen energy (GET request ke shop.php dengan link yang didapat)
        function doRegenEnergy() {
            loadRegenEnergyLink((err, regenLink) => {
                if (err) {
                    alert("Error: " + err);
                    return;
                }
                let regenUrl = "https://capitalcity.web.id/shop.php" + regenLink;
                fetch(regenUrl, {
                    method: "GET",
                    headers: shopHeaders,
                    credentials: "same-origin"
                })
                .then(response => response.text())
                .then(text => {
                    loadRegenEnergyStatus();
                })
                .catch(err => {
                    alert("Regen Energy Error: " + err);
                    console.error(err);
                });
            });
        }

        document.getElementById("refreshRegenEnergy").addEventListener("click", loadRegenEnergyStatus);
        document.getElementById("doRegenEnergy").addEventListener("click", doRegenEnergy);

        loadRegenEnergyStatus();
    }
    document.getElementById("regenEnergy").addEventListener("click", createRegenEnergyPopup);

    /* === UPDATE INFO POPUP === */
    let updatePopup = null;
    const updateInfoHTML = `
        <p><strong>Version:</strong> 1.0.0</p>
        <p><strong>Changelog:</strong></p>
        <ul>
            <li>Rilis awal Capital City Helper.</li>
            <li>Fitur Status, Regen Kesehatan, Regen Energy, Rat Hunter, dan Treasure Hunter telah ditambahkan.</li>
        </ul>
    `;
    function createUpdatePopup() {
        if (updatePopup) { updatePopup.remove(); }
        updatePopup = document.createElement("div");
        updatePopup.className = "popup";
        updatePopup.style.top = "50px";
        updatePopup.style.left = "50px";
        updatePopup.style.width = "300px";
        updatePopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Update Info</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                ${updateInfoHTML}
            </div>
        `;
        document.body.appendChild(updatePopup);
        makeDraggable(updatePopup, updatePopup.querySelector(".popupHeader"));
        updatePopup.querySelector(".closeBtn").addEventListener("click", () => {
            updatePopup.remove();
            updatePopup = null;
        });
        updatePopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(updatePopup, ".popupContent", this);
        });
    }
    document.getElementById("openUpdate").addEventListener("click", createUpdatePopup);

    /* === GAME MENU POPUP === */
    let gameMenuPopup = null;
    function createGameMenuPopup() {
        if (gameMenuPopup) { gameMenuPopup.remove(); }
        gameMenuPopup = document.createElement("div");
        gameMenuPopup.className = "popup gameMenuPopup";
        gameMenuPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Game Menu</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <div id="gameUserInfo" style="margin-bottom:10px; font-size:12px;">
                    ${localStorage.getItem("capitalCityPlayerId") ?
                        'Player ID: ' + localStorage.getItem("capitalCityPlayerId") + ' <button id="resetUserId">Reset</button>' :
                        'Player ID belum diset. Silakan kunjungi <a href="https://capitalcity.web.id/leaderboard.php?tab=onlineplayers" style="color:#0ff;">Online Players</a> dan klik nama Anda.'
                    }
                </div>
                <button id="gameRatHunter">Rat Hunter</button>
                <button id="gameTreasureHunter">Treasure Hunter</button>
            </div>
        `;
        document.body.appendChild(gameMenuPopup);
        makeDraggable(gameMenuPopup, gameMenuPopup.querySelector(".popupHeader"));
        gameMenuPopup.querySelector(".closeBtn").addEventListener("click", () => {
            gameMenuPopup.remove();
            gameMenuPopup = null;
        });
        gameMenuPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(gameMenuPopup, ".popupContent", this);
        });
        let resetBtn = document.getElementById("resetUserId");
        if (resetBtn) {
            resetBtn.addEventListener("click", () => {
                localStorage.removeItem("capitalCityPlayerId");
                document.getElementById("gameUserInfo").innerHTML = 'Player ID belum diset. Silakan kunjungi <a href="https://capitalcity.web.id/leaderboard.php?tab=onlineplayers" style="color:#0ff;">Online Players</a> dan klik nama Anda.';
            });
        }
        document.getElementById("gameRatHunter").addEventListener("click", () => {
            createRatHunterPopup();
        });
        document.getElementById("gameTreasureHunter").addEventListener("click", () => {
            createTreasureHunterPopup();
        });
    }
    document.getElementById("openGame").addEventListener("click", () => {
        if (gameMenuPopup) {
            gameMenuPopup.style.display = "block";
        } else {
            createGameMenuPopup();
        }
    });

    /* === RAT HUNTER, TREASURE HUNTER POPUPS (tetap seperti sebelumnya) === */
    let ratHunterPopup = null;
    function createRatHunterPopup() {
        if (ratHunterPopup) { ratHunterPopup.remove(); }
        ratHunterPopup = document.createElement("div");
        ratHunterPopup.className = "popup ratHunterPopup";
        ratHunterPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Rat Hunter</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <label for="ratMoneyEarned">Money Earned:</label>
                <select id="ratMoneyEarned">
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="30">30</option>
                    <option value="40">40</option>
                    <option value="50">50</option>
                </select>
                <br>
                <label for="ratReduceHealth">Reduce Health:</label>
                <select id="ratReduceHealth">
                    <option value="0">0</option>
                    <option value="1">1</option>
                </select>
                <br><br>
                <button id="sendRatUpdate">Send Update</button>
                <br><br>
                <label for="ratLoopInterval">Loop Interval (ms):</label>
                <input type="number" id="ratLoopInterval" value="2000" min="500" style="width:60px;">
                <br>
                <button id="startLoop">Start Loop</button>
                <button id="stopLoop" disabled>Stop Loop</button>
                <div id="ratHunterLog" style="margin-top:10px; font-size:12px;"></div>
            </div>
        `;
        document.body.appendChild(ratHunterPopup);
        makeDraggable(ratHunterPopup, ratHunterPopup.querySelector(".popupHeader"));
        ratHunterPopup.querySelector(".closeBtn").addEventListener("click", () => {
            if(ratLoopTimer) {
                clearInterval(ratLoopTimer);
                ratLoopTimer = null;
            }
            ratHunterPopup.remove();
            ratHunterPopup = null;
        });
        ratHunterPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(ratHunterPopup, ".popupContent", this);
        });
        function addLog(message) {
            let logContainer = document.getElementById("ratHunterLog");
            let newLog = document.createElement("div");
            newLog.textContent = message;
            logContainer.appendChild(newLog);
            while (logContainer.children.length > 3) {
                logContainer.removeChild(logContainer.firstChild);
            }
        }
        function sendRatUpdate() {
            let playerId = localStorage.getItem("capitalCityPlayerId");
            if (!playerId) {
                alert("Player ID belum diset. Silakan set terlebih dahulu.");
                return;
            }
            let moneyEarned = parseInt(document.getElementById("ratMoneyEarned").value);
            let reduceHealth = parseInt(document.getElementById("ratReduceHealth").value);
            const payload = {
                playerId: playerId,
                moneyEarned: moneyEarned,
                reduceHealth: reduceHealth
            };
            const updateUrl = "https://capitalcity.web.id/update.php";
            addLog("Mengirim request update...");
            const headers = {
                "Accept": "*/*",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "Content-Type": "application/json",
                "Origin": "https://capitalcity.web.id",
                "Referer": "https://capitalcity.web.id/arrow.php",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\""
            };
            fetch(updateUrl, {
                method: "POST",
                headers: headers,
                credentials: "same-origin",
                body: JSON.stringify(payload)
            })
            .then(response => response.text())
            .then(text => {
                addLog("Response: " + text);
            })
            .catch(err => {
                addLog("Error: " + err);
                console.error(err);
            });
        }
        document.getElementById("sendRatUpdate").addEventListener("click", sendRatUpdate);
        let ratLoopTimer = null;
        document.getElementById("startLoop").addEventListener("click", function() {
            if (!ratLoopTimer) {
                let interval = parseInt(document.getElementById("ratLoopInterval").value);
                ratLoopTimer = setInterval(sendRatUpdate, interval);
                this.disabled = true;
                document.getElementById("stopLoop").disabled = false;
                addLog("Loop dimulai dengan interval " + interval + " ms");
            }
        });
        document.getElementById("stopLoop").addEventListener("click", function() {
            if (ratLoopTimer) {
                clearInterval(ratLoopTimer);
                ratLoopTimer = null;
                this.disabled = true;
                document.getElementById("startLoop").disabled = false;
                addLog("Loop dihentikan");
            }
        });
    }
    let treasureHunterPopup = null;
    function createTreasureHunterPopup() {
        if (treasureHunterPopup) { treasureHunterPopup.remove(); }
        treasureHunterPopup = document.createElement("div");
        treasureHunterPopup.className = "popup treasureHunterPopup";
        treasureHunterPopup.innerHTML = `
            <div class="popupHeader">
                <span class="headerTitle">Treasure Hunter</span>
                <span class="minimizeBtn" title="Minimize">–</span>
                <span class="closeBtn" title="Close">x</span>
            </div>
            <div class="popupContent">
                <div id="treasureInfo">
                    <p id="tskeyDisplay">Loading TSKey...</p>
                </div>
                <button id="loadTSKey">Reload TSKey</button>
                <br><br>
                <button id="startTreasure">Start Treasure Hunt</button>
                <div id="treasureLog" style="margin-top:10px; font-size:12px;"></div>
            </div>
        `;
        document.body.appendChild(treasureHunterPopup);
        makeDraggable(treasureHunterPopup, treasureHunterPopup.querySelector(".popupHeader"));
        treasureHunterPopup.querySelector(".closeBtn").addEventListener("click", () => {
            treasureHunterPopup.remove();
            treasureHunterPopup = null;
        });
        treasureHunterPopup.querySelector(".minimizeBtn").addEventListener("click", function() {
            toggleMinimize(treasureHunterPopup, ".popupContent", this);
        });
        function addTreasureLog(message) {
            let logContainer = document.getElementById("treasureLog");
            let newLog = document.createElement("div");
            newLog.textContent = message;
            logContainer.appendChild(newLog);
            while (logContainer.children.length > 3) {
                logContainer.removeChild(logContainer.firstChild);
            }
        }
        let currentTSKey = "";
        function loadTSKey() {
            fetch("https://capitalcity.web.id/treasurehunt.php", {
                method: "GET",
                credentials: "same-origin"
            })
            .then(response => response.text())
            .then(html => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(html, "text/html");
                let tskeyInput = doc.querySelector("#tskey");
                if (tskeyInput) {
                    currentTSKey = tskeyInput.value;
                    document.getElementById("tskeyDisplay").textContent = "TSKey: " + currentTSKey;
                    addTreasureLog("TSKey diperbarui.");
                } else {
                    document.getElementById("tskeyDisplay").textContent = "TSKey tidak ditemukan.";
                    addTreasureLog("Gagal mendapatkan TSKey.");
                }
            })
            .catch(err => {
                document.getElementById("tskeyDisplay").textContent = "Error loading TSKey.";
                addTreasureLog("Error: " + err);
                console.error(err);
            });
        }
        loadTSKey();
        document.getElementById("loadTSKey").addEventListener("click", loadTSKey);
        async function startTreasureHunt() {
            if (!currentTSKey) {
                alert("TSKey belum tersedia.");
                return;
            }
            for (let i = 0; i <= 15; i++) {
                let payload = `index=${i}&points=0&tskey=${currentTSKey}`;
                addTreasureLog(`Mengirim request untuk index ${i}...`);
                try {
                    let response = await fetch("https://capitalcity.web.id/handle_click.php", {
                        method: "POST",
                        headers: {
                            "Accept": "*/*",
                            "Accept-Encoding": "gzip, deflate, br, zstd",
                            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "Origin": "https://capitalcity.web.id",
                            "Pragma": "no-cache",
                            "Priority": "u=1, i",
                            "Referer": "https://capitalcity.web.id/treasurehunt.php",
                            "Sec-CH-UA": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
                            "Sec-CH-UA-Mobile": "?0",
                            "Sec-CH-UA-Platform": "\"Windows\"",
                            "Sec-Fetch-Dest": "empty",
                            "Sec-Fetch-Mode": "cors",
                            "Sec-Fetch-Site": "same-origin",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
                            "X-Requested-With": "XMLHttpRequest"
                        },
                        credentials: "same-origin",
                        body: payload
                    });
                    let resText = await response.text();
                    addTreasureLog(`Index ${i} Response: ${resText}`);
                    try {
                        let resJson = JSON.parse(resText);
                        if (resJson.newKey) {
                            currentTSKey = resJson.newKey;
                            document.getElementById("tskeyDisplay").textContent = "TSKey: " + currentTSKey;
                            addTreasureLog(`TSKey diperbarui ke: ${currentTSKey}`);
                        }
                    } catch(e) {
                        console.warn("Response bukan JSON:", resText);
                    }
                } catch(err) {
                    addTreasureLog(`Error pada index ${i}: ${err}`);
                }
            }
            addTreasureLog("Treasure Hunt selesai.");
        }
        document.getElementById("startTreasure").addEventListener("click", startTreasureHunt);
    }

    // ----- Deteksi Perubahan URL (misalnya SPA) -----
    let lastUrl = location.href;
    setInterval(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            if (updatePopup) { createUpdatePopup(); }
        }
    }, 1000);
    window.addEventListener("popstate", () => {
        if (updatePopup) { createUpdatePopup(); }
    });

})();
